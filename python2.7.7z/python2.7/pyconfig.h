#ifndef Py_CONFIG_H
#define Py_CONFIG_H

#if defined WIN32
#include "pyconfig_win32.h"
#elif defined __linux__
#include "pyconfig_linux.h"
#endif

#endif /* !Py_CONFIG_H */
